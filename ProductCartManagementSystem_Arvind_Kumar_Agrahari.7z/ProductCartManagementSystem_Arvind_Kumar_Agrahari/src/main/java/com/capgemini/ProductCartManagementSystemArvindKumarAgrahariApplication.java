package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Main Class for running the application
@SpringBootApplication
public class ProductCartManagementSystemArvindKumarAgrahariApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagementSystemArvindKumarAgrahariApplication.class, args);
	}

}
